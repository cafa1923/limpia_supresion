
import requests
import time
class Api:
    KEY_APPI='evU9DHkAAx7yqNWCDd1q.azdk5xriRosahjEzxDf8oKu4TH25v_uQJ8larK6E'
    def get(self):
        headers = {'Content-Type': 'application/json','Accept': 'application/json','Authorization':f'Bearer {self.KEY_APPI}'}
        payload = {'emailAddress':'TITO11@HOTMAIL.COM'}
        url=f'https://api.socketlabs.com/v2/servers/11306/suppressions'
        res=requests.get(url,params=payload,headers=headers)
        print(res.json())

    def post(self,raw_datai):
        headers = {'Content-Type': 'application/json','Accept': 'application/json','Authorization':f'Bearer {self.KEY_APPI}'}
        raw_data='","'.join(raw_datai)
        url='https://api.socketlabs.com/v2/servers/11306/suppressions/bulk-remove'
        print('**********',f'["{raw_data}"]')
        #res=requests.post(url,headers=headers,data=f'["{raw_data}"]')
        #print(res.json())


def main():
    print("hola")
    api=Api()    
    #api.post()
    with open("suprimidos.txt",'r') as archivo:
        list_correos=archivo.read().splitlines()
        for x in range(0,len(list_correos)-1,100):
            rango_lista=list_correos[x:x+100]
            api.post(rango_lista)
            time.sleep(60)
    #son 1295 paginas

if __name__ =='__main__':
    main()
